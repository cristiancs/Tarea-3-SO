# Ejecución:

* python app.py 
* Este programa ha sido probado con python 3.4

* Recordar que para cerrar el programa se debe escribir -1, tienen que terminar todos los alumnos antes de que el programa finalice.

# Consideraciones:

* Se asume que el usuario ingresara una cantidad numerica de alumnos.
* Ya que el enunciado no lo indicaba he decidido que cada alumno se encarga de esperar y entrar en el casillero, lavamos, secador
* Asumo que al inicio hay papel higenico en el baño
* Asumo que no se ejecutara por más de 1 hora el programa, si se ejecuta más de 1 hora, los minutos pasaran de 60.

# Extra

Al inicio del archivo puse 2 variables que permiten configurar el programa

* cargas_papel : Permite indicar cada cuantos uso se debe recargar el papel de los casilleros

* log_console : Si su valor es True, aparte de guardar el log en los archivos, se muestra por consola.
